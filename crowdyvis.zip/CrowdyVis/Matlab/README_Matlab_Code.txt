CrowdyVis Crowd Dynamics Computational Tool: Matlab Files
=========================================================

General Information
-------------------

Version:        1.0

Authors:        Ardjan van der Linden
                Dylan Rijnen
         	Rick van der Ven
         	Roy Wolters

Sub Authors:	Joep Evers
		Alessandro Corbetta

Release Date: 	18-04-2014

Licence:	Apache Licence

Affiliations:	Eindhoven University of Technology (TU/e)
		Institute of Complex Molecular Systems (ICMS)
		Honors Horizon Program (TU/e)




What Is Included In This Package?
---------------------------------

1.MainProgram.m
2.basic_interactions.m
3.compiling_vv.m
4.create_looping_xpos.m
5.morse_potential_interactions.m
6.savepostofile.m
7.savetoxml.m
8.showSimulation.m
9.summing_of_forces.m
10.viewing_angle_interactions.m



Download Link
-------------

https://github.com/CrowdyVis/Matlab



What Can I do With This Package?
--------------------------------

This package has been designed to provide users with realistic crowd simulation
data. It focusses on the  implementation of first order counterflow problems.
When using the package, user are able to adapt the parameters of a simple 
corridor, or expand here on to create more complex geometry. The software will 
then compute the positions and velocities of multiple pedestrians using the 
Forward Euler method. The resulting data will be stored in XML files so that 
these can be used as input for a second piece of software. Provided with the XML
data files the secondary software package can create 3D visualisations of the 
simulation in real time. This code was written to provide ourselves with a means 
of generating realistic data to test the 3D visualization tool.  



How To Use The Package?
-----------------------

1. Ensure that you preside over a working version of Matlab (MathWorks, USA).
2. Add all data files to your Matlab path, if possible within the same folder. 
3. To begin usage, open up the MainProgram.m script in the Matlab editior. 
4. Run the script by pressing play or F5.
5. To make optimal use of the software, it is advised users read the User Manual
   provided before attempting to make drastic changes to the software. Detailled
   explanations of all files can also be found within the User Manual


Disclaimer
----------

This software was designed and created by students partaking in the TU/e Honors
Horizion program. This project was part of their extra curricular activities.
Whilst the students have attempted to adhere to correct academic protocol at all
times, the software provided has not been peer reviewed or formally tested by 
others. Use of this software is at your own risk, and the students can not be 
held accountable for any situations that may occur.   






