

savetoxml(pos, P, 'pedestrian_datasmooth1.xml', N)