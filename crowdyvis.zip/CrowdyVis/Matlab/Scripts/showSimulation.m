for i = 1:N
    plot([0 xmax], [ymax ymax], '-'); 
    hold on
    plot([0 xmax], [ymin ymin], '-');
    scatter(pos(1:P, i), pos(2*P+1:3*P, i), 'r');
    scatter(pos(P+1:2*P,i), pos(3*P+1:end,i), 'b');
    hold off
    xlim([0,xmax]);
    ylim([-.2*ymax,1.2*ymax])
    pause(0.000001)
end