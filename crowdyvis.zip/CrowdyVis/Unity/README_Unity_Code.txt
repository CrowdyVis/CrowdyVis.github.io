CrowdyVis: Crowd Dynamics Visulaization Tool: Unity Package
===========================================================

General Information
-------------------

Version:        1.0

Authors:        Ardjan van der Linden
                Dylan Rijnen
         	Rick van der Ven
         	Roy Wolters

Sub Authors:	Joep Evers
		Alessandro Corbetta

Release Date: 	18-04-2014

Licence:	Apache Licence

Affiliations:	Eindhoven University of Technology (TU/e)
		Institute of Complex Molecular Systems (ICMS)
		Honors Horizon Program (TU/e)




What Is Included In This Package?
---------------------------------

1.Combined_Code_Version_1.cs
2.Camera_Related_Functions.cs
3.Creation_Of_Positions_Array.cs
4.GUI_Functions.cs
5.Initialization.cs
6.MoveTest.cs
7.Movement_Related_Functions.cs
8.Variable_Definitions.cs
9.WallCreatorWithObstacles.cs



Download Link
-------------

https://github.com/CrowdyVis/CrowdVisualizationTUe.CSharpFiles



What Can I do With This Package?
--------------------------------

The purpose of this package is to provide users with the C# code created within 
this project. The code can be imported into the Unity environment to provide the
the user with a 3D visualization of his simulation data. This simulation data 
should be provided in the form of XML files as prescribed within the User Manual.
However, if the user imports only these files into the Unity environment then the
visualization software will not work as designed. To gain optimal performance the
user should also download the Unity Package which has been made available within
the same Github repository. With the addition of this Unity Package it becomes 
possible to view crowd dynamics in real time in a 3D environment. 




How To Use The Package?
-----------------------

!!! As mentioned users should also download the Unity Package as prescribed to 
!!! gain the full effects of the software. 

1. Ensure that the user presides over a working version of the Unity environment. 
2. Open a new project in within the Unity environment.
3. Import the Unity package provided by clicking the [Assets] menu and then 
   clicking the sub-menu [Import Package] and finally [Custom Package].
4. Using the explorer provided browse and select the downloaded package.
5. Wait for the package to decompress.
6. When the selection window pops up, ensure that all files are selected and 
   then click on [Import]. The package will now be added to your current Unity 
   project. 
7. Within the [Project] panel, browse to and open the [Scripts\_Combined\_Code] 
   folder. This contains all the C-Sharp scripts used to run the visulaization. 
   Should the user wish to adapt the functionality of the visualization tool in 
   any way, these are they files in which the changes should be made. 
8. Click on the script entitled [Combined\_Code\_Version\_1] and drag this into 
   the [Heirarchy] panel, attaching it to the [Main Camera]. 
9. The visualization tool should now be ready to use by clicking on the play button
   at the top of the Unity interface. 




Disclaimer
----------

This software was designed and created by students partaking in the TU/e Honors
Horizion program. This project was part of their extra curricular activities.
Whilst the students have attempted to adhere to correct academic protocol at all
times, the software provided has not been peer reviewed or formally tested by 
others. Use of this software is at your own risk, and the students can not be 
held accountable for any situations that may occur.   






