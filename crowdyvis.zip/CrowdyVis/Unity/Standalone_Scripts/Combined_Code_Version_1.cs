using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using UnityEditor;

// This class is the main class of the visualization program. It calls all other classes and functions with the
// aim of providing the user with a running simulation. All commands are sent  and all data is recieved within 
// this class. 
public partial class Combined_Code_Version_1 : MonoBehaviour
{
		// Start is the function which is run automatically at the start of our program, will be used to
		// instantiate our game objects once we have retrieved and ordered our data. 
		void Start ()
		{	
				//Provide a reference for the starting time of the program.
				startTime = Time.time;
				
				// Creates instances for other classes to be called on during initialization
				initializer = new Initialization ();
				movementClass = new Movement_Related_Functions (numberOfPedestrians, numberOfSteps, positions, 
		                                             	prefabBlue, prefabRed, rotationSpeed, pedestrians);
		}

		// If a simulation is selected in which only the geometry is to be shown, then the following function
		// initialize only those items needed for the viewing of the geometry.
		public void viewGeometry ()
		{
				initializer.instantiateGeometry (Floor, ExtWall, IntWall, Obst);
				instantiateCameras ();
				instantiateScreenshots ();
				geometry = true;
		}
		
		// If a simulation is selected in which both the geometry as well as the pedestrian movement is to be shown
		// the following function will be called and will initialize the neccessary items. It will also ensure that 
		// references to the pedestrians, the position data and the selection of puppets or speheres is returned to 
		// this main code. 
		public void startSimulation ()
		{	
				initializer.instantiateGeometry (Floor, ExtWall, IntWall, Obst);
				pedestrians = initializer.selectionSetup ();
				positions = initializer.instantiatePositionsData ();		
				spheres = initializer.instantiatePedestrians (prefabBlue, prefabRed, rotationSpeed);
				instantiateCameras ();
				instantiateScreenshots ();
				simulation = true;
				finished = false;
				
				// Define global variables for later use. 
				numberOfPedestrians = (positions.GetLength (0)) / 2;
				numberOfSteps = positions.GetLength (1);
		}
		
		// This function is used to instantiate the cameras, setting their initial positions and calibrating their variables.
		public void instantiateCameras ()
		{
				// Creates an instance of the class housing all camera related functions.
				cameraClass = new Camera_Related_Functions ();
				
				// Define the initial distance of the camera to a game object.
				heightWanted = height;
				distanceWanted = distance;
			
				// Setup our default camera. 
				zoomResult = new Vector3 (0f, height, -distance);
			
				// Determine the maximum value the pedestrian camera can have (the value determines which pedestrian is being watched).
				MaxCam = spheres.Count - 1; 
			
				// Defining the camera transform.
				_myTransform = transform;
			
				// Starting position of the new camera
				_myTransform.position = new Vector3 (10, 2, 10);
				
				// Starting angle of the new camera
				_myTransform.LookAt(new Vector3(50,0,12));
		}
	
		public void instantiateScreenshots ()
		{
				screenshotFoldername = "";
				while(screenshotFoldername == "") {
						if (EditorUtility.DisplayDialog ("Please select a folder for saving screenshots", "", "OK", "Cancel")) {
								screenshotFoldername = EditorUtility.OpenFolderPanel ("Open folder for screenshots", "D:\\Desktop", "");
						}
				}
				Debug.Log (screenshotFoldername);
		}

		// The update function is called once every frame. 
		void Update ()
		{
				// Simulation entails that the user has opted to not simply view the geometry.
				if (simulation) {
						// If the simulation has ended:
						if (finished) {
								// Display message allowing for the user to choose his/her next action.
								if (EditorUtility.DisplayDialog ("Simulation has finished", "The simulation is finished. If you want to replay the simulation, click Replay. " +
										"If you want to go back to the main menu, click Home", "Replay", "Home")) {
										resetCounter = true; // reset counter is true for one frame only.
										finished = false; // The simulation is no longer finished after a selection has been made.
								} else {
										stopSimulation (); // Breaks off the simulation.
								}
						} else {
								// If the simulation has not yet finished:
								float time = Time.time;
								
								// In the following line the position of each gameObject is updated. Camnum holds the value of the pedestrian which 
				                // the first person camera should be following.
								CamNum = movementClass.moveGameObjects (threshold, threshold2, time, CamNum, resetCounter, spheres, 
				                                        numberOfPedestrians, numberOfSteps, positions, pedestrians);
								
								// Counting in Unity begins at 0. Number of pedestrians can thus never be the value of CamNum. Therefore when the 
								// simulation has finished, i.e. when the number of steps taken == the number of steps calculated, then the value 
								// CamNum is set to the number of pedestrians being simulated. This entails that if these two are equal, then the 
								// simulation has ended and the variable finished should be set as such. CamNum is reset to zero to avoid errors.
								if (CamNum == numberOfPedestrians) {
										finished = true;
										CamNum = 0;
								}
				
								// Resets the resetCounter boolean. If button reset is pressed then the boolean is set to true and the index will be set at 
								// 1. This needs to occur once so after each movement update, the boolean needs to be given the value false. Only when
								// the button is pressed should the animation reset. If this loop is left out, then the animation will continue to 
								// reset continually after the button has been pressed once. 
								if (resetCounter == true) {
										resetCounter = false;
								}
				
								
								// Here the value CamNum is used to select the appropriate gameobject from the spheres list. This transform then become the 
								// first person camera target. 
								Transform target = spheres [CamNum];	
								
								// Within this function the entire camera movement is dealt with. 
								CamNum = cameraClass.moveCamera (CamNum, target, doZoom, zoomStep, zoomSpeed, min, max, time, _myTransform, Getswap, 
				                                 spheres, smooth, damping, bewegen, xspeed, yspeed, factor, manualcamera, point);
								

						
						}
				}
				

				// If the user has selected to only view the geometry and not the simulation then the following will occur:
				if (geometry) {
						float time = Time.time;
						// A secondary camera fucntion is called which only controls the manual camera. There is no longer an option
						// for a first person camera.
						cameraClass.geometryCamera (doZoom, zoomStep, zoomSpeed, min, max, time, _myTransform, smooth, damping, bewegen, 
			                           xspeed, yspeed, factor, manualcamera, point);
		
				}
				
		}
	
		// The following code outlines the function of the buttons which are shown on screen during the simulation.
		// The first GUI button is used to capture screenshots.
		void OnGUI ()
		{
				// Define the name and the location of the screenshot should it be taken. 
				while (System.IO.File.Exists (screenshotFoldername +  "/screenshot" + countScreenshots + ".png")) {
						capturingScreenshot = false;
						countScreenshots += 1;
				}
				
				// Only when not capturing screenshots can the following buttons be on screen. (When capturing screenshots the buttons disappear. 
				if (!capturingScreenshot) {
						if (geometry) {
								cameraButtons ();
								screenShotButtons ();
						} else if (simulation) {
								cameraButtons ();
								screenShotButtons ();
								simulationButtons ();
						} else {
								homeButtons ();
						}
				}
		}
		
		// The homebuttons are shown at the beginning of each simulation allowing the user to select what type of simulations he would like to see.
		private void homeButtons ()
		{
				if (GUI.Button (new Rect (Screen.width * .1f, Screen.height * .1f, Screen.width * .35f, Screen.height * .8f), "View geometry")) {
						viewGeometry ();
				}
				if (GUI.Button (new Rect (Screen.width * .55f, Screen.height * .1f, Screen.width * .35f, Screen.height * .8f), "Start simulation")) {
						startSimulation ();
				}
		}

		// Buttons relating to the camera.
		private void cameraButtons ()
		{
				// Button only works if a simulation is running and not if only the geometry is being viewed.
				if (simulation) {
						// Will allow the switching between pedestrians using the buttons new object and prev. object.
						if (Getswap == true) {
								// previous cam
								if (GUI.Button (new Rect (380, 10, 95, 30), "new object")) {
										CamSwap ();
								}
								// next cam
								if (GUI.Button (new Rect (480, 10, 90, 30), "prev.object")) {
										PrevCam ();
								}
						}
				
						// Determines the type of camera being used: the manual camera with which the user can freely move around or the 
						// first person camera which is aimed at a target around which the user can then pan. Upon button press the 
						// camera function will change. 
						if (GUI.Button (new Rect (270, 10, 105, 30), " newcamera")) {
								if (manualcamera == true) {
										manualcamera = false;
										Getswap = true;
								} else if (manualcamera == false) {
										manualcamera = true;
										Getswap = false;
								}
						}
				}
				
				// If the manual camera has been selected and the reset button is pressed then the camera will obtain its original position 
				// orientation. Therefore if the user loses sight of the simulation whilst moving around the game space this button will 
				// him to his original position.
				if (manualcamera) {
						if (GUI.Button (new Rect (10, 80, 50, 50), "reset")) {
							// Resetting the camera postion
							_myTransform.position = new Vector3 (10.0f, 2.0f, 10.0f);
											// Resetting the camera angle
							_myTransform.LookAt (new Vector3(50,0,12));
						}	
				}
		}
		
		// The following buttons are used to control the asthetics of the simulation. 
		private void simulationButtons ()
		{
				// pPlay/ Pause button.
				if (Time.timeScale == 0) {
						if (GUI.Button (new Rect (10, 10, 60, 30), "Play")) {
								Time.timeScale = 1.0f;
						}
				} else {
						if (GUI.Button (new Rect (10, 10, 60, 30), "Pause")) {
								Time.timeScale = 0.0f;
						}
				}
				// Changes the speed of the animation either doubling or halving the current speed. Can be pressed multiple times. 
				if (GUI.Button (new Rect (75, 10, 60, 30), "x2")) {
						Time.timeScale *= 2;
				}
				if (GUI.Button (new Rect (140, 10, 60, 30), "x.5")) {
						Time.timeScale /= 2;
				}
				// Label indicating the current play speed. 
				GUI.Box (new Rect (205, 10, 60, 30), Time.timeScale.ToString ());
			
				// Button to reset the animation to its original state and start the simulation anew.
				if (GUI.Button (new Rect (140, 45, 50, 30), "Replay")) {
						resetCounter = true;
				}

				if (GUI.Button (new Rect (205, 45, 50, 30), "Home")) {
						stopSimulation ();
						homeButtons ();
				}

		}
		
		// Button used to create the screenshot.
		private void screenShotButtons ()
		{
				if (GUI.Button (new Rect (10, 45, 125, 30), "Screenshot " + countScreenshots)) {
						Application.CaptureScreenshot (screenshotFoldername + "/screenshot" + countScreenshots + ".png");
						capturingScreenshot = true;
				}
		}

		// The following fucntion is called when the new object button is pressed. It will chage the value of CamNum. In
		// doing so the first person camera will change. If this value equals the maximal number of pedestrians then the 
		// camera target is reset to pedestrian number 0. 
		public void CamSwap ()
		{
				if (CamNum >= MaxCam) {
						CamNum = 0; 	
				} else {
						CamNum ++; 
				}
		}

		// The following fucntion is called when the prev. object button is pressed. It will chage the value of CamNum. In
		// doing so the first person camera will change. If this value equals 0 then the camera target is reset to the 
		// maximum number of pedestrians within the simulation minus 1 (counting starts at zero). 
		public void PrevCam ()
		{
				if (CamNum > 1) {
						CamNum --;
				} else {
						CamNum = MaxCam-1;
				}
		}
		
		// Function used to break off the simulation. All gameobejcts are destroyed and all variables are reset. 
		void stopSimulation ()
		{
				for (int i = 0; i < numberOfPedestrians; i++) {
						if (spheres [i]) {
								Destroy (spheres [i].gameObject);
						}
				}
				destroyFunction ("InteriorWall");
				destroyFunction ("ExteriorWall");
				destroyFunction ("Obstacle");
				destroyFunction ("Floor");
				resetCounter = true;
				finished = false;
				simulation = false;
		}

		// A simple function to simplify the destruction of game objects based on their tags. 
		void destroyFunction (String tag)
		{
				GameObject[] gameObjects = GameObject.FindGameObjectsWithTag (tag);
		
				for (var i = 0; i < gameObjects.Length; i ++) {
						Destroy (gameObjects [i]);
				}
		}
	
}
